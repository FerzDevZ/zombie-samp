/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.19-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: laststand_s2
-- ------------------------------------------------------
-- Server version	10.11.19-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(24) NOT NULL,
  `password_hash` varchar(72) NOT NULL,
  `email` varchar(120) DEFAULT NULL,
  `created_at` bigint(20) NOT NULL,
  `last_login_at` bigint(20) NOT NULL DEFAULT 0,
  `last_ip` varchar(45) DEFAULT NULL,
  `is_banned` tinyint(1) NOT NULL DEFAULT 0,
  `admin_level` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_accounts_username` (`username`),
  KEY `idx_accounts_admin` (`admin_level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `anticheat_flags`
--

DROP TABLE IF EXISTS `anticheat_flags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `anticheat_flags` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `char_id` int(10) unsigned NOT NULL,
  `flag_type` varchar(32) NOT NULL,
  `payload` varchar(255) NOT NULL DEFAULT '',
  `created_at` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_flags_char_time` (`char_id`,`created_at`),
  KEY `idx_flags_type` (`flag_type`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `anticheat_flags`
--

LOCK TABLES `anticheat_flags` WRITE;
/*!40000 ALTER TABLE `anticheat_flags` DISABLE KEYS */;
/*!40000 ALTER TABLE `anticheat_flags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bans`
--

DROP TABLE IF EXISTS `bans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bans` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_id` int(10) unsigned NOT NULL,
  `reason` varchar(128) NOT NULL,
  `admin_name` varchar(24) NOT NULL DEFAULT 'console',
  `expires_at` bigint(20) NOT NULL DEFAULT 0,
  `created_at` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_bans_account` (`account_id`),
  CONSTRAINT `fk_bans_account` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bans`
--

LOCK TABLES `bans` WRITE;
/*!40000 ALTER TABLE `bans` DISABLE KEYS */;
/*!40000 ALTER TABLE `bans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `barricades`
--

DROP TABLE IF EXISTS `barricades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `barricades` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `base_id` int(10) unsigned NOT NULL,
  `model` smallint(5) unsigned NOT NULL,
  `pos_x` float NOT NULL,
  `pos_y` float NOT NULL,
  `pos_z` float NOT NULL,
  `rot_x` float NOT NULL DEFAULT 0,
  `rot_y` float NOT NULL DEFAULT 0,
  `rot_z` float NOT NULL DEFAULT 0,
  `health` smallint(5) unsigned NOT NULL DEFAULT 1500,
  `lobby_id` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_barricades_base` (`base_id`),
  CONSTRAINT `fk_barricades_base` FOREIGN KEY (`base_id`) REFERENCES `bases` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `barricades`
--

LOCK TABLES `barricades` WRITE;
/*!40000 ALTER TABLE `barricades` DISABLE KEYS */;
/*!40000 ALTER TABLE `barricades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `base_structures`
--

DROP TABLE IF EXISTS `base_structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `base_structures` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `base_id` int(10) unsigned NOT NULL,
  `struct_id` tinyint(3) unsigned NOT NULL,
  `pos_x` float NOT NULL,
  `pos_y` float NOT NULL,
  `pos_z` float NOT NULL,
  `rot_z` float NOT NULL DEFAULT 0,
  `health` int(10) unsigned NOT NULL DEFAULT 1,
  `fuel` float NOT NULL DEFAULT 0,
  `created_at` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_structures_base` (`base_id`),
  CONSTRAINT `fk_structures_base` FOREIGN KEY (`base_id`) REFERENCES `bases` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `base_structures`
--

LOCK TABLES `base_structures` WRITE;
/*!40000 ALTER TABLE `base_structures` DISABLE KEYS */;
/*!40000 ALTER TABLE `base_structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bases`
--

DROP TABLE IF EXISTS `bases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bases` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `char_id` int(10) unsigned NOT NULL,
  `shelter_id` tinyint(3) unsigned NOT NULL,
  `name` varchar(32) NOT NULL DEFAULT 'Shelter',
  `tier` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `pos_x` float NOT NULL DEFAULT 0,
  `pos_y` float NOT NULL DEFAULT 0,
  `pos_z` float NOT NULL DEFAULT 0,
  `lobby_id` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_bases_shelter` (`shelter_id`),
  KEY `idx_bases_char` (`char_id`),
  CONSTRAINT `fk_bases_char` FOREIGN KEY (`char_id`) REFERENCES `characters` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bases`
--

LOCK TABLES `bases` WRITE;
/*!40000 ALTER TABLE `bases` DISABLE KEYS */;
/*!40000 ALTER TABLE `bases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_skills`
--

DROP TABLE IF EXISTS `character_skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `character_skills` (
  `char_id` int(10) unsigned NOT NULL,
  `skill_id` tinyint(3) unsigned NOT NULL,
  `level` tinyint(3) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`char_id`,`skill_id`),
  CONSTRAINT `fk_character_skills_char` FOREIGN KEY (`char_id`) REFERENCES `characters` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_skills`
--

LOCK TABLES `character_skills` WRITE;
/*!40000 ALTER TABLE `character_skills` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_skills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `characters`
--

DROP TABLE IF EXISTS `characters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `characters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_id` int(10) unsigned NOT NULL,
  `slot` tinyint(3) unsigned NOT NULL,
  `name` varchar(24) NOT NULL,
  `skin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `gender` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `age` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `race` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `origin` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `occupation` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `trait` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `appearance` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `level` smallint(5) unsigned NOT NULL DEFAULT 1,
  `xp` int(10) unsigned NOT NULL DEFAULT 0,
  `cash` int(10) unsigned NOT NULL DEFAULT 500,
  `scrap` int(10) unsigned NOT NULL DEFAULT 0,
  `rank_points` int(10) unsigned NOT NULL DEFAULT 0,
  `infection` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `health` float NOT NULL DEFAULT 100,
  `hunger` float NOT NULL DEFAULT 100,
  `thirst` float NOT NULL DEFAULT 100,
  `zone_id` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `pos_x` float NOT NULL DEFAULT 1685,
  `pos_y` float NOT NULL DEFAULT -2333,
  `pos_z` float NOT NULL DEFAULT 13,
  `pos_a` float NOT NULL DEFAULT 0,
  `stash_capacity` tinyint(3) unsigned NOT NULL DEFAULT 60,
  `last_seen_at` bigint(20) NOT NULL DEFAULT 0,
  `playtime_sec` int(10) unsigned NOT NULL DEFAULT 0,
  `skill_points` smallint(5) unsigned NOT NULL DEFAULT 0,
  `lobby_id` tinyint(4) NOT NULL DEFAULT 0,
  `bladder` float NOT NULL DEFAULT 0,
  `wounds` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `tutorial_step` tinyint(4) NOT NULL DEFAULT 0,
  `tutorial_count` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_characters_name` (`name`),
  UNIQUE KEY `uq_characters_slot` (`account_id`,`slot`),
  KEY `idx_characters_account` (`account_id`),
  CONSTRAINT `fk_characters_account` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `characters`
--

LOCK TABLES `characters` WRITE;
/*!40000 ALTER TABLE `characters` DISABLE KEYS */;
/*!40000 ALTER TABLE `characters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companions`
--

DROP TABLE IF EXISTS `companions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `companions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `char_id` int(10) unsigned NOT NULL,
  `name` varchar(24) NOT NULL,
  `health` float NOT NULL DEFAULT 100,
  `mode` tinyint(4) NOT NULL DEFAULT 0,
  `tier` tinyint(4) NOT NULL DEFAULT 0,
  `recruited_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_companion_char` (`char_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companions`
--

LOCK TABLES `companions` WRITE;
/*!40000 ALTER TABLE `companions` DISABLE KEYS */;
/*!40000 ALTER TABLE `companions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contracts`
--

DROP TABLE IF EXISTS `contracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contracts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `char_id` int(10) unsigned NOT NULL,
  `day_id` int(10) unsigned NOT NULL,
  `slot` tinyint(3) unsigned NOT NULL,
  `kind` tinyint(3) unsigned NOT NULL,
  `target` smallint(5) unsigned NOT NULL,
  `progress` smallint(5) unsigned NOT NULL DEFAULT 0,
  `reward_cash` int(10) unsigned NOT NULL DEFAULT 0,
  `reward_item` smallint(5) unsigned NOT NULL DEFAULT 0,
  `reward_amount` smallint(5) unsigned NOT NULL DEFAULT 0,
  `claimed` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `created_at` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_contract` (`char_id`,`day_id`,`slot`),
  KEY `idx_contract_day` (`day_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contracts`
--

LOCK TABLES `contracts` WRITE;
/*!40000 ALTER TABLE `contracts` DISABLE KEYS */;
/*!40000 ALTER TABLE `contracts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grave_items`
--

DROP TABLE IF EXISTS `grave_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `grave_items` (
  `grave_id` int(10) unsigned NOT NULL,
  `slot` tinyint(3) unsigned NOT NULL,
  `item_id` smallint(5) unsigned NOT NULL,
  `amount` smallint(5) unsigned NOT NULL,
  `durability` tinyint(3) unsigned NOT NULL DEFAULT 100,
  PRIMARY KEY (`grave_id`,`slot`),
  CONSTRAINT `fk_grave_items_grave` FOREIGN KEY (`grave_id`) REFERENCES `graves` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grave_items`
--

LOCK TABLES `grave_items` WRITE;
/*!40000 ALTER TABLE `grave_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `grave_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `graves`
--

DROP TABLE IF EXISTS `graves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `graves` (
  `id` int(10) unsigned NOT NULL,
  `char_id` int(10) unsigned NOT NULL,
  `owner_name` varchar(24) NOT NULL,
  `lobby_id` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `world_id` int(11) NOT NULL DEFAULT 0,
  `pos_x` float NOT NULL,
  `pos_y` float NOT NULL,
  `pos_z` float NOT NULL,
  `expires_at` bigint(20) NOT NULL,
  `created_at` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_graves_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `graves`
--

LOCK TABLES `graves` WRITE;
/*!40000 ALTER TABLE `graves` DISABLE KEYS */;
/*!40000 ALTER TABLE `graves` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory` (
  `char_id` int(10) unsigned NOT NULL,
  `slot` tinyint(3) unsigned NOT NULL,
  `item_id` smallint(5) unsigned NOT NULL,
  `amount` smallint(5) unsigned NOT NULL DEFAULT 1,
  `durability` smallint(5) unsigned NOT NULL DEFAULT 100,
  PRIMARY KEY (`char_id`,`slot`),
  KEY `idx_inventory_item` (`item_id`),
  CONSTRAINT `fk_inventory_char` FOREIGN KEY (`char_id`) REFERENCES `characters` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_ledger`
--

DROP TABLE IF EXISTS `item_ledger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `item_ledger` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `char_id` int(10) unsigned NOT NULL,
  `item_id` smallint(5) unsigned NOT NULL,
  `delta` smallint(6) NOT NULL,
  `reason` varchar(32) NOT NULL,
  `ref_id` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ledger_char_time` (`char_id`,`created_at`),
  KEY `idx_ledger_item` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_ledger`
--

LOCK TABLES `item_ledger` WRITE;
/*!40000 ALTER TABLE `item_ledger` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_ledger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kill_log`
--

DROP TABLE IF EXISTS `kill_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `kill_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `killer_id` int(10) unsigned NOT NULL DEFAULT 0,
  `victim_id` int(10) unsigned NOT NULL DEFAULT 0,
  `victim_kind` tinyint(3) unsigned NOT NULL,
  `zombie_type` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `weapon_id` tinyint(3) unsigned NOT NULL,
  `dist_m` float NOT NULL DEFAULT 0,
  `zone_id` tinyint(3) unsigned NOT NULL,
  `created_at` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kill_time` (`created_at`),
  KEY `idx_kill_killer` (`killer_id`,`created_at`),
  KEY `idx_killlog_zone` (`zone_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kill_log`
--

LOCK TABLES `kill_log` WRITE;
/*!40000 ALTER TABLE `kill_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `kill_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loot_nodes`
--

DROP TABLE IF EXISTS `loot_nodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `loot_nodes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `zone_id` tinyint(3) unsigned NOT NULL,
  `tier` tinyint(3) unsigned NOT NULL,
  `node_kind` tinyint(3) unsigned NOT NULL,
  `pos_x` float NOT NULL,
  `pos_y` float NOT NULL,
  `pos_z` float NOT NULL,
  `respawn_at` bigint(20) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_loot_zone_active` (`zone_id`,`is_active`,`respawn_at`),
  KEY `idx_loot_tier` (`tier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loot_nodes`
--

LOCK TABLES `loot_nodes` WRITE;
/*!40000 ALTER TABLE `loot_nodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `loot_nodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `owned_vehicles`
--

DROP TABLE IF EXISTS `owned_vehicles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `owned_vehicles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `char_id` int(10) unsigned NOT NULL,
  `model` smallint(5) unsigned NOT NULL,
  `plate` varchar(16) NOT NULL DEFAULT '',
  `fuel` float NOT NULL DEFAULT 45,
  `health` float NOT NULL DEFAULT 1000,
  `locked` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `created_at` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_owned_char` (`char_id`),
  CONSTRAINT `fk_owned_char` FOREIGN KEY (`char_id`) REFERENCES `characters` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `owned_vehicles`
--

LOCK TABLES `owned_vehicles` WRITE;
/*!40000 ALTER TABLE `owned_vehicles` DISABLE KEYS */;
/*!40000 ALTER TABLE `owned_vehicles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `party_stash`
--

DROP TABLE IF EXISTS `party_stash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `party_stash` (
  `char_id` int(10) unsigned NOT NULL,
  `slot` tinyint(3) unsigned NOT NULL,
  `item_id` smallint(5) unsigned NOT NULL,
  `amount` smallint(5) unsigned NOT NULL DEFAULT 1,
  `durability` smallint(5) unsigned NOT NULL DEFAULT 100,
  PRIMARY KEY (`char_id`,`slot`),
  CONSTRAINT `fk_party_stash_char` FOREIGN KEY (`char_id`) REFERENCES `characters` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `party_stash`
--

LOCK TABLES `party_stash` WRITE;
/*!40000 ALTER TABLE `party_stash` DISABLE KEYS */;
/*!40000 ALTER TABLE `party_stash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `schema_migrations` (
  `version` varchar(32) NOT NULL,
  `applied_at` bigint(20) NOT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schema_migrations`
--

LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` VALUES
('001_init',0);
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stash`
--

DROP TABLE IF EXISTS `stash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `stash` (
  `char_id` int(10) unsigned NOT NULL,
  `slot` tinyint(3) unsigned NOT NULL,
  `item_id` smallint(5) unsigned NOT NULL,
  `amount` smallint(5) unsigned NOT NULL DEFAULT 1,
  `durability` smallint(5) unsigned NOT NULL DEFAULT 100,
  PRIMARY KEY (`char_id`,`slot`),
  CONSTRAINT `fk_stash_char` FOREIGN KEY (`char_id`) REFERENCES `characters` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stash`
--

LOCK TABLES `stash` WRITE;
/*!40000 ALTER TABLE `stash` DISABLE KEYS */;
/*!40000 ALTER TABLE `stash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vehicles`
--

DROP TABLE IF EXISTS `vehicles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehicles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `owner_char_id` int(10) unsigned NOT NULL,
  `model` smallint(5) unsigned NOT NULL,
  `plate` varchar(16) NOT NULL,
  `pos_x` float NOT NULL,
  `pos_y` float NOT NULL,
  `pos_z` float NOT NULL,
  `pos_a` float NOT NULL DEFAULT 0,
  `color1` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `color2` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `paintjob` tinyint(4) NOT NULL DEFAULT 3,
  `mods` varchar(96) NOT NULL DEFAULT '',
  `fuel` float NOT NULL DEFAULT 100,
  `health` float NOT NULL DEFAULT 1000,
  `mileage_km` float NOT NULL DEFAULT 0,
  `is_locked` tinyint(1) NOT NULL DEFAULT 1,
  `is_impounded` tinyint(1) NOT NULL DEFAULT 0,
  `garage_zone` tinyint(3) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_vehicles_owner` (`owner_char_id`),
  CONSTRAINT `fk_vehicles_owner` FOREIGN KEY (`owner_char_id`) REFERENCES `characters` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicles`
--

LOCK TABLES `vehicles` WRITE;
/*!40000 ALTER TABLE `vehicles` DISABLE KEYS */;
/*!40000 ALTER TABLE `vehicles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weapons`
--

DROP TABLE IF EXISTS `weapons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `weapons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `char_id` int(10) unsigned NOT NULL,
  `weapon_id` tinyint(3) unsigned NOT NULL,
  `ammo` smallint(5) unsigned NOT NULL DEFAULT 0,
  `weapon_condition` tinyint(3) unsigned NOT NULL DEFAULT 100,
  `upgrades` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_weapons_char_weapon` (`char_id`,`weapon_id`),
  KEY `idx_weapons_char` (`char_id`),
  CONSTRAINT `fk_weapons_char` FOREIGN KEY (`char_id`) REFERENCES `characters` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weapons`
--

LOCK TABLES `weapons` WRITE;
/*!40000 ALTER TABLE `weapons` DISABLE KEYS */;
/*!40000 ALTER TABLE `weapons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'laststand_s2'
--

--
-- Dumping routines for database 'laststand_s2'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-19  4:00:02
